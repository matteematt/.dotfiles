return {
	settings = {

    python = {
      analysis = {
        typeCheckingMode = "off"
      }
    }
	},
}
